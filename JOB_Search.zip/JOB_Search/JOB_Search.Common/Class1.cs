﻿using System;

namespace JOB_Search.Common
{
    public class Class1
    {

    }
}
