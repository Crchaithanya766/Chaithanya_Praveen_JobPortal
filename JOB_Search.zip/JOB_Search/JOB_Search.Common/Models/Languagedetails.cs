﻿using System;
using System.Collections.Generic;

namespace JOB_Search.API.Models
{
    public partial class Languagedetails
    {
        public int LanguageId { get; set; }
        public string Language { get; set; }
    }
}
