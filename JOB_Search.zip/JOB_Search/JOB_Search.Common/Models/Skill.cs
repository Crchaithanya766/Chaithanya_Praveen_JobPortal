﻿using System;
using System.Collections.Generic;

namespace JOB_Search.API.Models
{
    public partial class Skill
    {
        public int SkillId { get; set; }
        public string SkillName { get; set; }
    }
}
