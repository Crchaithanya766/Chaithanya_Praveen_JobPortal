﻿using JOB_Search.API.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace JOB_Search.Data.Services.Abstract
{
    public abstract class Languages
    {
        public abstract List<Languagedetails> GetallLanguages();
        public abstract int AddLanguage(Languagedetails languagedetails);
    }
}
