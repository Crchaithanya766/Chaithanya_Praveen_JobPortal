﻿using JOB_Search.API.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace JOB_Search.Data.Services.Abstract
{
    public abstract class Skills
    {
        public abstract List<Skill> GetallSkills();
        public abstract int AddSkill(Skill skill);
    }
}
