﻿using JOB_Search.API.Models;
using JOB_Search.Data.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JOB_Search.Data.Services.Derived
{
    public class LanguageService : Languages
    {
        readonly jobapplication_dbContext db = new jobapplication_dbContext();
        public override int AddLanguage(Languagedetails languagedetails)
        {
            db.Languagedetails.Add(languagedetails);
            int recordInserted = db.SaveChanges();
            return recordInserted;
        }

        public override List<Languagedetails> GetallLanguages()
        {
            return db.Languagedetails.ToList();
        }
    }
}
