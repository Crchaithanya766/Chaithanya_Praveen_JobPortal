﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JOB_Search.API.Models;
using JOB_Search.Data.Services.Abstract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JOB_Search.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LanguageController : ControllerBase
    {
        private readonly Languages _languages;

        public LanguageController(Languages languages)
        {
            _languages = languages;
        }

        [HttpGet("GetAllLanguages")]
        public IActionResult GetAllUsers()
        {
            var data = _languages.GetallLanguages();
            if (data != null)
            {
                return Ok(new { status = 200, success = true, response = data });
            }
            else
            {
                return Ok(new { status = 401, success = false, response = "Languages not found" });
            }
        }

        [HttpPost("AddLanguage")]
        public IActionResult AddLanguage(Languagedetails languagedetails)
        {
            int data = _languages.AddLanguage(languagedetails);
            if (data > 0)
            {
                return Ok(new { status = 200, success = true, response = "Language added successfully" });
            }
            else
            {
                return Ok(new { status = 401, success = false, response = "Language not added." });
            }
        }
    }
}
