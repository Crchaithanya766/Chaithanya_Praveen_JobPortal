﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JOB_Search.API.Models;
using JOB_Search.Data.Services.Abstract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JOB_Search.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SkillController : ControllerBase
    {
        private readonly Skills _skills;

        public SkillController(Skills skills)
        {
            _skills = skills;
        }

        [HttpGet("GetAllSkills")]
        public IActionResult GetAllSkills()
        {
            var data = _skills.GetallSkills();
            if (data != null)
            {
                return Ok(new { status = 200, success = true, response = data });
            }
            else
            {
                return Ok(new { status = 401, success = false, response = "Skills not found" });
            }
        }

        [HttpPost("AddSkill")]
        public IActionResult AddSkill(Skill skill)
        {
            int data = _skills.AddSkill(skill);
            if (data > 0)
            {
                return Ok(new { status = 200, success = true, response = "Skill added successfully" });
            }
            else
            {
                return Ok(new { status = 401, success = false, response = "Skill not added." });
            }
        }
    }
}
