using JOB_Search.API.Models;
using JOB_Search.Data.Services.Abstract;
using JOB_Search.Data.Services.Derived;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace JOB_Search
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<jobapplication_dbContext>(options =>
           options.UseMySQL("Server=127.0.0.1;Database=jobportal_db;Uid=root;Pwd=chaithu@#9010;"));
            services.AddControllers();
            services.AddTransient<JobProfileSearch, JobProfileSearchService>();
            services.AddTransient<UserDetails, UserDetailsService>();
            services.AddTransient<Skills, SkillService>();
            services.AddTransient<Languages, LanguageService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
